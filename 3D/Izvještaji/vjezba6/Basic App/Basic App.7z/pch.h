﻿#pragma once

#include<Vanity.h>