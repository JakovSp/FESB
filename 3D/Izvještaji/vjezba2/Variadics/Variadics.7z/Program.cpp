#include<iostream>

#define DEBUG
#include"Templates.h"
using namespace std;
using namespace vtl;
using namespace std::string_literals;

int main() {

	Log(L"a", L"b");
	// Log(L"a", L"b", 1, 1);

	return 0;
}